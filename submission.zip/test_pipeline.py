import pandas as pd
from config import PARTNER_CONFIG
from eligibility_pipeline import standardize_dataframe, format_phone


def test_format_phone():
    assert format_phone('5551234567') == '555-123-4567'
    assert format_phone('555-222-3333') == '555-222-3333'
    assert format_phone('(555) 444-5555') == '555-444-5555'
    assert format_phone('123') is None


def test_standardize_and_dropped_acme():
    # Build a small Acme-like dataframe with one bad row (missing MBI) and one bad dob
    data = [
        {"MBI": "A1", "FNAME": "john", "LNAME": "doe", "DOB": "03/15/1955", "EMAIL": "JOHN@EMAIL.COM", "PHONE": "5551234567"},
        {"MBI": "", "FNAME": "noid", "LNAME": "user", "DOB": "01/01/1980", "EMAIL": "noid@example.com", "PHONE": "5550000000"},
        {"MBI": "A3", "FNAME": "bad", "LNAME": "date", "DOB": "bad-date", "EMAIL": "bad@example.com", "PHONE": "5551112222"},
    ]
    df = pd.DataFrame(data)

    conf = PARTNER_CONFIG['ACME']
    std_df, dropped_df = standardize_dataframe(df, conf)

    # With new rule we only drop missing external_id; rows with bad DOB should be kept
    assert len(std_df) == 2
    ids = set(std_df['external_id'].tolist())
    assert 'A1' in ids and 'A3' in ids
    # First standardized row name/email checks
    row_a1 = std_df[std_df['external_id'] == 'A1'].iloc[0]
    assert row_a1['first_name'] == 'John'
    assert row_a1['email'] == 'john@email.com'

    # One dropped row expected (the one with missing MBI)
    assert len(dropped_df) == 1
    assert 'partner_code' in dropped_df.columns
